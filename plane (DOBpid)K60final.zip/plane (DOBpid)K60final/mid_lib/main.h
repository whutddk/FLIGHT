/**
****��ͷ�ļ�
*****�����
2014 11 29 
*/


#ifndef _MAIN_H_
#define _MAIN_H_

extern uint8 flag_5ms;
extern uint8 flag_10ms;
extern uint8 flag_20ms;
extern uint8 flag_30ms;
extern uint8 flag_60ms;
extern uint8 flag_70ms;
extern uint8 flag_80ms;
extern uint8 flag_90ms;
extern uint8 flag_100ms;
extern uint8 flag_250ms;
extern uint8 flag_500ms;
extern uint8 flag_1s;
extern uint8 flag_100us ;
extern uint8 flag_200us ;
extern uint8 flag_300us ;
extern uint8 flag_400us ;
extern uint8 flag_500us ;
extern uint8 flag_600us ;
extern uint8 flag_700us ;
extern uint8 flag_800us ;
extern uint8 flag_900us ;
extern uint8 flag_1ms ;


#endif