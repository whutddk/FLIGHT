#ifndef _MID_NVIC_H_
#define _MID_NVIC_H_

void NVIC_set();


#endif
