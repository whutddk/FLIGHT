#ifndef _RCPIN_H_
#define _RCPIN_H_

extern uint8 miss_cnt;

extern double chn[20];
void check_pin();

#endif

